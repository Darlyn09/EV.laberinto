using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Disparar : MonoBehaviour
{
    public Rigidbody projectile;       // Prefab de la bala
    public Transform barrelEnd;       // Punto de salida
    public float projectileForce = 200f;
    public float fireRate = 0.2f;
    private float nextFireTime = 0f;

    void Update()
    {
        if (Input.GetButtonDown("Fire1") && Time.time >= nextFireTime)
        {
            nextFireTime = Time.time + fireRate;

            // Instanciar la bala
            Rigidbody projectileInstance = Instantiate(projectile, barrelEnd.position, barrelEnd.rotation);
            projectileInstance.velocity = barrelEnd.forward * projectileForce;

            // Ignorar colisi�n con el jugador
            Collider playerCollider = GetComponent<Collider>();
            Collider bulletCollider = projectileInstance.GetComponent<Collider>();
            if (playerCollider != null && bulletCollider != null)
            {
                Physics.IgnoreCollision(playerCollider, bulletCollider);
            }

            // Destruir la bala despu�s de 3 segundos
            Destroy(projectileInstance.gameObject, 3f);
        }
    }
}
